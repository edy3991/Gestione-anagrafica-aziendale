<?php
session_start();
	if (isset($_POST["utente"]) &&
		isset($_POST["password"]))   {

				$scuola = "vrit0007";
				$utente = $_POST["utente"];
        $password = $_POST["password"];
                // chiamo il webservice
        $url = "https://web.spaggiari.eu/services/ws/wsExtAuth.php?wsdl";
        $client = new SoapClient( $url );
        $result = $client->__soapCall("wsExtAuth..ckAuth",    array(
                        'cid' =>$scuola,
                        'login' =>$utente,
                        'password' => $password));


        /*il webservice restituisce 3 array, il primo [0] contiene eventuali errori,
		il secondo [1] la descrizione degli errori ed
		infine il terzo [2] se i primi due sono vuoti conterrà le informazioni dell'account (dati di esempio):*/


		if(!empty($result[0])){
			// echo "login errato";
			header("Location: ../index.php");
			die();
                    //no login - restituito codice errore (il dettaglio dell'errore è nel secondo array $result[1] ma noi lo ignoriamo per un più generico messaggio predefinito di joomla)
			// print("errore !!<br>");
			// print($result[1]);
		}else {
			// echo "login corretto";
			$_SESSION["scuola"] = "vrit0007";
			$_SESSION["utente"] = $_POST["utente"];
			$_SESSION["password"] = $_POST["password"];
			header("Location: ../bin/anagrafica.php");
			die();
			// $info=$result[2];			//echo $result;
      // var_dump($info);
			// echo "<br>";
			// echo "edio";
		}

	}
?>
