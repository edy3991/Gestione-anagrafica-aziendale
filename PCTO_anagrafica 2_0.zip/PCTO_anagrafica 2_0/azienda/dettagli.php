<?php
session_start();
if (!isset($_SESSION["scuola"]) || !isset($_SESSION["utente"]) || !isset($_SESSION["password"])) {
  header("Location: ../index.php");
  die();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Golden PCTO Imaralu/Gruia</title>

  <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
    <link href="css/small-business.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../bin/css/util.css">

  </head>

<body>
  <!-- php -->
  <?php
  include_once '../bin/connect.php';
  $Id = $_GET['id'];

  $sql = "SELECT * FROM azienda WHERE Id like $Id";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  $ragione_sociale = $row['Ragione_sociale'];
  $telefono = $row['Telefono'];
  $email = $row['Email'];
  $sito = $row['Sito'];
  $indirizzo = $row['Indirizzo'];
  $comune = $row['Comune'];
  $provincia = $row['Provincia'];
  $tipo_azienda = $row['Tipo_azienda'];
  $articolazione = $row['Articolazione'];
  $codice_ateco = $row['Codice_ATECO'];
  $descrizione_ateco = $row['Descrizione_ATECO'];

   ?>
  <!-- /php -->

  <!-- Page Content -->
  <div class="container">

    <!-- Heading Row -->
    <div class="row align-items-center my-5">
      <div class="col-lg-6 m-2">
        <iframe class="img-fluid rounded mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2800.098457170106!2d10.969686515556267!3d45.42751657910064!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477f5f61f8852227%3A0xfab7331910c8e071!2sITIS%20G.%20Marconi!5e0!3m2!1sit!2sit!4v1584474879405!5m2!1sit!2sit" width="700" height="600" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      <!-- /.col-lg-8 -->
      <div class="col-lg-5">
        <h1 class="font-weight-light fs-50"><?php echo $ragione_sociale; ?></h1>
        <p><?php echo $descrizione_ateco; ?></p>
        <!-- <a class="btn btn-primary" href="#">Call to Action!</a> -->
      </div>
      <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->

    <!-- Call to Action Well -->
    <div class="card text-white bg-secondary my-5 py-4 text-center">
      <div class="card-body">
        <h2 class="text-white m-0">Informazioni</h2>
      </div>
    </div>

    <!-- Content Row -->
    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">TELEFONO</h2>
            <p class="card-text"><?php echo $telefono; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">E-MAIL</h2>
            <p class="card-text"><?php echo $email; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">SITO</h2>
            <p class="card-text"><?php echo $sito; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->

    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">INDIRIZZO</h2>
            <p class="card-text"><?php echo $indirizzo; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">COMUNE</h2>
            <p class="card-text"><?php echo $comune; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">PROVINCIA</h2>
            <p class="card-text"><?php echo $provincia; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->

    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">TIPO AZIENDA</h2>
            <p class="card-text"><?php echo $tipo_azienda; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">ARTICOLAZIONE</h2>
            <p class="card-text"><?php echo $articolazione; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <div class="card-body">
            <h2 class="card-title">CODICE ATECO</h2>
            <p class="card-text"><?php echo $codice_ateco; ?></p>
          </div>

        </div>
      </div>
      <!-- /.col-md-4 -->

    </div>
    <!-- /.row -->


  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Golden PCTO Copyright by Golden Team 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
